# Prosit-1.10
Prosit sur la qualité du code
echo "# Prosit-1.10" >> README.md
git init
git add README.md
git commit -m "first commit"
git remote add origin https://github.com/ClmtScz/Prosit-1.10.git
git push -u origin master
